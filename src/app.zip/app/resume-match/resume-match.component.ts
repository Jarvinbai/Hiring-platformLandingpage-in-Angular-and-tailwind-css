import { Component } from '@angular/core';

@Component({
  selector: 'app-resume-match',
  standalone: true,
  imports: [],
  templateUrl: './resume-match.component.html',
  styleUrl: './resume-match.component.css'
})
export class ResumeMatchComponent {

}
