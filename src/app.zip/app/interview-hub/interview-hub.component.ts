import { Component } from '@angular/core';

@Component({
  selector: 'app-interview-hub',
  standalone: true,
  imports: [],
  templateUrl: './interview-hub.component.html',
  styleUrl: './interview-hub.component.css'
})
export class InterviewHubComponent {

}
