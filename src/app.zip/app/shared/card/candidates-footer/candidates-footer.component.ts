import { Component } from '@angular/core';
import { ButtonComponent } from '../../button/button.component';

@Component({
  selector: 'app-candidates-footer',
  standalone: true,
  imports: [ButtonComponent],
  templateUrl: './candidates-footer.component.html',
  styleUrl: './candidates-footer.component.css'
})
export class CandidatesFooterComponent {

}
