import { Component } from '@angular/core';
import { RatingComponent } from '../../rating/rating.component';

@Component({
  selector: 'app-jobs-footer',
  standalone: true,
  imports: [RatingComponent],
  templateUrl: './jobs-footer.component.html',
  styleUrl: './jobs-footer.component.css'
})
export class JobsFooterComponent {
  rating=4.5;
}
