import { Component, Input } from '@angular/core';
import { JobsFooterComponent } from './jobs-footer/jobs-footer.component';
import { CandidatesFooterComponent } from './candidates-footer/candidates-footer.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-card',
  standalone: true,
  imports: [CommonModule,JobsFooterComponent,CandidatesFooterComponent],
  templateUrl: './card.component.html',
  styleUrl: './card.component.css'
})
export class CardComponent {
  @Input('type')
  type='J' //J ,C
}
