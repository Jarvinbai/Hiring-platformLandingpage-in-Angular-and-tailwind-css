import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ResumeMatchComponent } from './resume-match/resume-match.component';
import { InterviewHubComponent } from './interview-hub/interview-hub.component';
import { TestComponent } from './test/test.component';
import { JobslistComponent } from './jobslist/jobslist.component';
import { CandidateslistComponent } from './candidateslist/candidateslist.component';

export const routes: Routes = [
    {path:'', component:HomeComponent},
    {path:'jobs',component:JobslistComponent},
    {path:'candidates',component:CandidateslistComponent},
    {path:'resumematch',component:ResumeMatchComponent},
    {path:'interviewhub',component:InterviewHubComponent},
    {path:'test',component:TestComponent},
];